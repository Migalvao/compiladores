class ifwhile {

    public static boolean b;
    public static int i;
    public static double d;

    public static void main(String[] args) {
        boolean bl;
        boolean t;
        boolean f;

        if(t) {
            while(b)
            while(true) {
                    System.out.print(i);
                    System.out.print(b);
                    System.out.print(d);
                } ;
            System.out.print("Gotcha!");
            while(true) {
                if (f)
                    ;
                else {
                    while (f) System.out.print(d);
                    System.out.print("Twice!");
                }
                System.out.print("Thrice!");
            }
        }
        while(false) System.out.print(b);
    }
}