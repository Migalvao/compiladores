class test {
    public static void main(String[] args) {
		double n1, n2;
		n1 = -11;
		n2 = -53;
		System.out.print(n2 / n1);
		System.out.print("\n");
		int n3, n4;
		n3 = -11;
		n4 = -53;
		System.out.print(n4 / n3);
		System.out.print("\n");
		n3 = 11;
		n4 = -53;
		System.out.print(n4 / n3);
		System.out.print("\n");
		n3 = 2;
		n4 = -85;
		System.out.print(n4 % n3);
		System.out.print("\n");
		n3 = -2;
		n4 = 85;
		System.out.print(n4 % n3);
		System.out.print("\n");
		n3 = 2;
		n4 = 85;
		System.out.print(n4 % n3);
		System.out.print("\n");
		
		n2=n1=0;
	}
}