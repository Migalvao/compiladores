//flag -e2

class Factorial {
    public static boolean b, a, c;
    public static boolean a(){
        "String"
    }
    public static int factorial(int n) {
    }
//Tem menos uma chaveta em baixo, não recupera deste erro