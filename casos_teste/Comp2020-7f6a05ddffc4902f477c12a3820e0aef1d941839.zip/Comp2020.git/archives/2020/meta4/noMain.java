class fluxControl1 {
    //It's necessary to add a main method 'by hand' at *.ll file
    public static int a (int input){
		return input;
    }
    
    public static int b(int input){
		return input;
    }
}