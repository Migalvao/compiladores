int a, A1, A5, A4;
char blah(int r);
char c1;
char localvars(
    int A0,
    char A1,
    short A2,
    double A3,
    int A4,
    char C0) {
    char c0, c1, c2, c3, c4;
    int a0, a1, a2, a3, a4;
    double b1, b2, b3, b4;
    int blah, localvars;
}
char C1, C2, C3, C4;
char localvars(
    int A0,
    char A1,
    short A2,
    double A3,
    int A4,
    char C0);
char blah(int q) {
    int blah, localvars, f;
    char p, b;
    int i,j,k;
    short v;
}
char C1, C2, C3, C4;
int zf23(int x);
void f(void) {
    char c0, c1, c2, c3, c4;
    int a0, a1, a2, a3, a4;
    double b1, b2, b3, b4;
    short d1, d2, d3, d4;
}