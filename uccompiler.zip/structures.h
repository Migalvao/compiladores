#ifndef STRUCTURES_H
#define STRUCTURES_H

typedef struct _s1 {
    char * type;
    struct _s1 * children;
    struct _s1 * next;
} program;

#endif
