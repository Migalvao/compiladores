class Factorial {
    public static int operators(int n) {
       int x,b,a;
       double y;
       x=b<<a;
       b=x*a;
       y=x*(1.0+b);

    }

    public static void main(String[] args) {
        operators();
    }
}
