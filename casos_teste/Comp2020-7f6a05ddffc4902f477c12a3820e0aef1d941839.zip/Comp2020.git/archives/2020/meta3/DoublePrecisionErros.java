class Echo1 {
    public static void main (String[] args) {
    System.out.print(2.5E-324);                
    System.out.print(0.002_4E-321);            
    System.out.print(0.5E-4965);            

    }
}

