class test {
  public static boolean b;
    // Correr com 7
    public static void main(String[] args) {
      b = !true;
      System.out.print(!!!!!!(!b));
      System.out.print("\n");
      System.out.print(-(-420.0));
      System.out.print("\n");
      System.out.print(!(-+-+-+-+-420>-421));
		  System.out.print("\n");
      System.out.print(!(false==falseB()));
      System.out.print("\n");
      System.out.print(-+-+-Integer.parseInt(args[-(-(1-1+0))]));
      System.out.print("\n");
	}
  public static boolean falseB(){
    return !true;
  }
}
