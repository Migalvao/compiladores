class various {
	public static int main(String[] args){
		int a;
		a = Integer.parseInt(args[0])
		str();
		str(true);
		str("por terminar );
		;;
	}
}