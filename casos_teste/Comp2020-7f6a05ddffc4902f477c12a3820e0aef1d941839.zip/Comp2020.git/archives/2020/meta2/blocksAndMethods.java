class Main {
    public static int test1(int a, double c)
    {
    	a = c + 3 * 8 >> 4 - 2 + (5+c)%10 % 3;
    	int k, d, a;
    }
    public static int test2()
    {

    }
    public static int test3(String[] args)
    {
    	if(a);
    	while(b);
    	if(a){

    	} else
    	{
    		p = test1(Integer.parseInt(args[0]), Integer.parseInt(args[1]));
    	}
    }
}
