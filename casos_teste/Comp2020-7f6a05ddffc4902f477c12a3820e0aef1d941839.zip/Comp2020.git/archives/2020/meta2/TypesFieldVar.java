// -t, test types declaration in field and method
class Factorial {
	public static double comp, hello;
    public static boolean b, a, c;
    public static void a(double a, double b){
        int a,b;
    }
    public static boolean factorial(int n) {
    	double r,y,x;
    }
}