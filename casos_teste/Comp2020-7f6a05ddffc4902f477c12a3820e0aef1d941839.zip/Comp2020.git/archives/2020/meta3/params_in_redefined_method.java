class test {

    public static void a(int a, int b){}
    public static void a(int a, int a){} // não ignorar, mesmo que seja redefinição de a(int,int)


    public static void main(String[] args){

    }

}