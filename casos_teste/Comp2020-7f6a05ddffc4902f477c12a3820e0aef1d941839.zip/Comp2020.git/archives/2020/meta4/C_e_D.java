class CeD{
	public static int a;
	public static void main(String[] args){
		a = 2;
		System.out.print(a);
		System.out.print("\n");
		int i,a,i1,i2,i3;
		double d;
		d = a = 0 +3;
		System.out.print(a);
		System.out.print("\n");
		System.out.print(d);
		System.out.print("\n");
		System.out.print("Teste\tde \fstring\\\"\r%%");
		System.out.print("\n");
		System.out.print( (a = a +1) >0 || (a = a +3) >0);
		System.out.print("\n");
		System.out.print(a);
		System.out.print("\n");
		System.out.print((a = a +1) <0 && (a = a +3)<0);
		System.out.print("\n");
		System.out.print(a);
		System.out.print("\n");
		d = 123e-10;
		System.out.print(d);
		System.out.print("\n");
		d = .0e-10;
		System.out.print(d);
		System.out.print("\n");
		d = 1.e0_1;
		System.out.print(d);
		System.out.print("\n");
	}
	public static int b,c,d;


}