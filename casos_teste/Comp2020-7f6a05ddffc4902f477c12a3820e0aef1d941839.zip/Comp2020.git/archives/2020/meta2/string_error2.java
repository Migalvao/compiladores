class Teste {
  public static int main(String[] args){
    call("invalid \| string");
    System.out.print("String string");
    call("valid string");
  }
}
