//  #include <stdio.h>
double le_double(void)
{
    return 1 + 1;
}
int w1(void)
{
    int a = 1;
    if (a)
    {
    }
    return 1;
}
int w2(void)
{
    return 0;
}
int w(void)
{
    int a = 1;
    int b = 10;
    while (a != b)
    {
        a = a + 1;
        while (a != b)
        {
            a = a + 1;
            while (a != b)
            {
                a = a + 1;
            }
        }
    }
    return 1;
}

int relf(void)
{
    // int a = 2, b = 3;
    // int c = a % b;
    int a;
    // int b = !a;

    return 100;
}
int aaa = 1;
int meeeh(void)
{
    int a;
    // int b = !aaa;
    // double d = aaa % 2;
    return 100;
}
int g1 = 0, g2 = 0, g3;
int flow(void)
{
}
int flow2(int a, int b)
{
    if (a == 1)
    {
        b = 3;
        // if (b == a)
        // {
        //     a = 1;
        //     // if (b == a)
        //     // {
        //     //     a = 1;
        //     // }
        // }
    }
    return 0;
}

int shapo(void)
{
    // int a;
    // if (a + a)
    // {
    //     a = 1;
    //     relf();
    //     if (a)
    //     {
    //         meeeh();
    //     }
    // }
    // return 100;
    // int f = (meeeh() && relf()) || (g && aaa);
    return 100;
}

int AND(void)
{
    int b = (aaa) || ((meeeh()) && shapo() && (meeeh()) && shapo());
    int c = (aaa) || ((meeeh()) && shapo() && (meeeh()) && shapo());
    // (aaa) || ((meeeh()) && shapo()) || ((meeeh()) && shapo());
    // int aa = relf() & meeeh();
    int bb = relf() && meeeh();
    return 1;
}

void OR(void)
{
    int c = (aaa) || ((meeeh()) && shapo() && (meeeh()) && shapo());
    // int a = relf() | meeeh();
    // int bb = relf() || meeeh();
    // relf() && meeeh();
    // int bbb = relf() || meeeh();
    // relf() || meeeh();
    // relf() || meeeh();
    // relf() || meeeh();
    // relf() || meeeh();
    // (relf() || meeeh()) + (relf() || meeeh());
    // relf() || meeeh();
    // int bbbb = relf() || meeeh();
}
void XOR(void)
{
    // int a = relf() ^ meeeh();
    // int b = relf() || meeeh();
    // relf() && meeeh();
    // int a;
    // while (a == relf())
    // {
    // a = 2;
    // }
}
void rel(void)
{
    int a;
    if (relf() == meeeh())
    {
    }
}

int f1(int a, double d);

int f2(int i)
{
    int a, b;
    a = 1;
    b = a + 1;
    return 105;
}

int f3(int a, double d)
{
    return 105 + a;
}

int boo(int b)
{
    putchar(b);
    return b;
}

int a = 2;
short f10s(void);
// int b;
int main(void)
{
    int a = boo(1) || boo(2);
    rel();
    a = '\12';
    char e = ',';
    int i = f3(1, 1.1);
    short s = 1 + '\n' + 1 + (i = 101);
    char c = 1 + 1 + 1 + 90;
    double d = 1 % 5 + 1 * 1.1;
    double ddd = 1.1 + 1 * 1.1;
    double exp = 2e2 + (boo(1) && boo(0) && boo(1) || boo(2));
    d = f2(1 + 1);
    // i = f2(1 + 1 + 1 + 1);
    d = 1;
    // i = 1;
    s = 1;
    c = 1;
    int inteiro = 1 + 3 * -+-+-(33 & (2 && +-+-+-boo(72))) + 4 + 6 + 43 + 'a' * 'r';
    int rr;
    rr = 97;
    putchar(rr);
    a = 99;
    putchar(a);
    // i = -i;
    // short get = getchar();
    // putchar(get + 1);
    putchar((a = 100));
    f1(10, 3);
    boo(99);
    putchar(inteiro);
    putchar(boo(99) + 10);
    putchar('\060');
    putchar('\60');
    putchar(f2(1));
    putchar(f3(-1, 1.1));
    putchar('\n' * 9);
    putchar('\t');
    putchar('\'');
    putchar('\"');
    putchar('\\');
    putchar(a);
    putchar(e + !0);
    putchar(i + !1);
    putchar('\100');
    putchar(97 % 140);
    putchar('\n');
    putchar(e - (1 == 1));
    putchar(97 + (1 <= 1.1) * (2 & 1) + (10 | 5) - (2 ^ 10));
    putchar(97 + (boo(0) && boo(0)));
    double dd = a * a;
    putchar(96 + ((boo(1) && boo(0)) && (boo(1) || (boo(2) && (boo(1) || boo(2))))));
    putchar('1');
    putchar(011710);
    putchar(2 + 3 - +-4 + 1 + 'A' % 90);
    putchar(2 + 3 - +4 + 1 + 'A');
    putchar((boo(104), relf(), 97));

    int b = 0;
    b = b * -1;

    if ((g2 + g1) != 1)
    {
        g3 = 1;
        if (meeeh() != (relf() && g1 && aaa))
        {
            putchar(101);
            g3 = 1;
        }
        else
        {
            putchar(102);
        }
        putchar(103);
        g3 = 1;
        if (meeeh() != (relf() && g1 && aaa))
        {
            putchar(104);
            g3 = 1;
        }
        else
        {
            putchar(105);
        }
        putchar(106);
    }
    else
    {

        putchar(107);
        g2 = 1;
    }
    (boo(1) && boo(2) && boo(3) && boo(10) && boo(40));
    while (((boo(90) + 1 && (boo(30) && boo(60))), b < 10))
    {
        b = b + 1;

        if (b < 5)
        {
            putchar(66);
        }
        else
            putchar(99);

        putchar(97);
    }
    while (((boo(90) + 1 && (boo(30) && boo(60))), b < 10))
    {
        b = b + 1;

        if (b < 5)
        {
            return 1;
        }
        else
            putchar(99);

        putchar(97);
    }
    while (((boo(90) + 1 && (boo(30) && boo(60))), b < 10))
    {
        b = b + 1;

        if (b < 5)
        {
            putchar(99);
        }
        else
            return 1;

        putchar(97);
    }
    if (a ^ 1)
    {
        putchar(67);
    }
    putchar(67);
    putchar(108);
    putchar(0141);
    putchar(10);
    putchar(0141);
    putchar(f1(97, 1.1));
    putchar(f10s());

    return 0;
}

int f1(int a, double d)
{

    putchar(boo(90));
    return 1;
}

int f10(int a)
{
    return 1;
}
short f10s(void)
{
    return 1;
}
char f10c(void)
{
}
double f10d(void)
{
}
