class onlyClass {
    
}