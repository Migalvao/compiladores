class Factorial {
    public static int operators(int n) {
       int x,b,a;
       double y;
       boolean z;
       boolean t;
       if(x==b && z==t){
        y=(a<<b)*1.0;
       }else{
        y=a%y;
       }

    }

    public static void main(String[] args) {
        operators();
    }
}
