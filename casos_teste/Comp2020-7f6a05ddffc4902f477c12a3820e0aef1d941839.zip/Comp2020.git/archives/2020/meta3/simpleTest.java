class ThatsWhatSheSaid{

  public static double main2(){
      int a;
      double b;
      a = b;
      b = a = b;
      a = a*b;
      a = a==b;
      return a;
  }
  public static int main(String[] args) {
        int argument;
        double iterator;
        args = args * args + args || args && args;
        args = args * 1 + main(args) || true && args;
        args = args < 1 >= main(args) == true != args;
        args = true < 1 && args == 1.0 && 2 != main(args);
        args = args && args || args;
        args = args;
        argument =  1 * argument + 1.0;
        argument =  Integer.parseInt(args[args.length -1]);
        argument = argument*argument+argument/argument%iterator;
        iterator = argument;
        if (argument > iterator) {}
        if (argument == iterator) {}
        if (argument >= iterator) {}
        if (argument > argument) {}
        if (argument > argument) {}
        if (args > argument) {}
        return main(argument);
        return args;
        return;
    }
  public static int one() {
    return 1;
    return 1.0;
  }
  public static double two() {
    return 1;
    return 1.0;
  }
}
