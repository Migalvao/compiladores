int A0, A1, A2, A3, A4;
short B1, B2, B3, B4;
char C0, C1, C2, C3, C4;
double D1, D2, D3, D4;
char argc; int argv; /* so para confundir */
int main(void) {
    A0, A1, (A2, A3, A4),
    D4, (D1, D2, D3), D4,
    C0, (C1, (C2, C3, C4,
    B1, B2), B3), B4,
    argc, argv;
}