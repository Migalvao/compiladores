class errors {

    public static int a, b, c;
    public static int c, a, b;
    public static double _;

    public static int underscore(int ola) {
      if (ola) {
        return ola;
      }else{
        return ola;
      }
      int ola;
    }
    public static void factorial(int i, int i) {
        int argument;
        int i;
        int argument;
        int a;
        double i,_;
    }

    public static void factorial(int i, int i,int _) {
      i = i + i;
    }
}
