//compilar com flag -e2

class Teste_Erros {
    public static int a, b, c;
    public static double preco;
    public boolean vivo;

    ;;;;;;;;;;

    public static int getNumero() {
        while (preco < 100000) {
            preco = a + b + c;
            a = a + ;
            b = b + 1.5;
            c = c + 10;
        }
        return preco / 10;
    }

    public static boolean estaVivo() {
        if (vivo == true && preco != 0) {
            "we out here";
        }
        else {
            preco = getNumero();
            preco = preco >> 2;
            "dat boi dead";
        }
        return vivo;
    }

    public static void main(String[] args) {
        tamanho = a.length;
        if (a == (b == c) {
            Integer.parseInt(a[a^a]);   //ParseArgs com xor
            Integer.parseInt(b[-b!c]);    //ParseArgs com menos
            Integer.parseInt(c[!c]);    //ParseArgs com not
        }
        
        passar(cg,comp(meta2),iia,lpa,si,scc);


    }
}