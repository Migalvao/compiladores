class Main {

    public static boolean bool(){
        boolean i;
        i=true;
        System.out.print(i);
        System.out.print("\n");
        return i;
    }

    public static int integer(){
        int i;
        i=1;
        System.out.print(i);
        System.out.print("\n");
        return i;
    }

    public static double real(){
        double i;
        i=1.0;
        System.out.print(i);
        System.out.print("\n");
        return i;
    }


    public static void main(String[] args) {
        bool();
        integer();
        real();
		System.out.print("\n");
    }
}