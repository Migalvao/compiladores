class Main {
    public static void main(String[] args) {
        int i;
        i = 3;
        double j;
        j = 4;
       	if(i+1==j){
       		System.out.print(j);
       	}
		System.out.print("\n");
      
    }
}