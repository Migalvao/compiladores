/*
	PARA ESTE CASO DE TESTE O RESULTADO SO E UM FICHEIRO VARIO SE COMPILAREM
	COM A FLAG -e2, CASO COMPILEM COM -t E SUPOSTO IMPRIMIR A ARVORE
*/
// o output e um ficheiro vazio
// o output e um ficheiro vazio
class Factorial {;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;// o output e um ficheiro vazio
    public static int covid19(int n,boolean hgshag) {// o output e um ficheiro vazio
      int oi;// o output e um ficheiro vazio
      int okds,oti,rrr;// o output e um ficheiro vazio
      boolean wtf;// o output e um ficheiro vazio
    }// o output e um ficheiro vazio
// o output e um ficheiro vazio
    public static void main(String[] args) {// o output e um ficheiro vazio
        int argument;// o output e um ficheiro vazio
// o output e um ficheiro vazio
    }// o output e um ficheiro vazio
}// o output e um ficheiro vazio
// o output e um ficheiro vazio
